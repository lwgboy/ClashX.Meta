//
//  WebPortalManager.swift
//  ClashX
//
//  Created by yicheng on 2019/1/11.
//  Copyright © 2019 west2online. All rights reserved.
//

import Cocoa

class WebPortalManager {
    static let shared = WebPortalManager()
    static let hasWebProtal = false

    func addWebProtalMenuItem(_ menu: inout NSMenu) {}
}
