BartyCrouch update && BartyCrouch lint
# swiftformat . --disable initCoderUnavailable,wrapArguments, andOperator, enumNamespaces, unusedArguments,numberFormatting,redundantReturn,andOperator,anyObjectProtocol,trailingClosures,redundantFileprivate --ranges nospace --swiftversion "5.0"
