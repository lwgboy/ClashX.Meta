rm -f *.h *.a
python3 build_clash.py
